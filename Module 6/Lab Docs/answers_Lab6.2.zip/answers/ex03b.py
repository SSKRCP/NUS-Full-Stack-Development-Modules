temp_f = float(input("Enter temperature in Fahrenheit: "))
temp_c = (temp_f - 32) * 5 / 9
print('{} Fahrenheit is equal to {} Celsius'.format(temp_f, temp_c))
