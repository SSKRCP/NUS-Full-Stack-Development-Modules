usd = float(input("Enter amount in USD: "))
sgd = usd * 1.3100
print('{} USD is equal to {} SGD'.format(usd, sgd))
