sgd = float(input("Enter amount in SGD: "))
usd = sgd / 1.3100
print('{} SGD is equal to {} USD'.format(sgd, usd))
