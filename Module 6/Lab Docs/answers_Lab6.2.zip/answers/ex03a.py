temp_c = float(input("Enter temperature in Celsius: "))
temp_f = (temp_c * 9 / 5) + 32
print('{} Celsius is equal to {} Fahrenheit'.format(temp_c, temp_f))
