Run the following command to restore the required node modules:

npm install
