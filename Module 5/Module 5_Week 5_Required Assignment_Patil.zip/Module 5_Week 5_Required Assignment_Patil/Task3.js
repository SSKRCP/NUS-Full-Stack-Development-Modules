/*** Define an array with four different fruit names */
let fruits =["Mango","Papaya","Grapes","Banana"]; 


/**** Iterate through the array and write fruit names to the console. */
for(var index in fruits){
    console.log('The fruit at index ' +  index + ' in fruits array is : ' + fruits[index]);     
}