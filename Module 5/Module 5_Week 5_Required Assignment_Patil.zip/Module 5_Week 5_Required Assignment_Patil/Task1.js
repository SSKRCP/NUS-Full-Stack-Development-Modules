/*** Declaring variables */
let myName;
let myAge;
let isStudent ;

/*** Assigning values to variables */
myName = 'Alice';
myAge = 22;
isStudent = true;

/*** Displaying variable values and datatypes */
console.log('The value of variable myName is : ' + myName );
console.log('The datatype of variable myName is : ' + typeof(myName));

console.log('The value of variable myAge is : ' + myAge);
console.log('The datatype of variable myAge is : ' + typeof(myAge));

console.log('The value of variable isStudent is : ' + isStudent);
console.log('The datatype of variable isStudent is : ' + typeof(isStudent));

