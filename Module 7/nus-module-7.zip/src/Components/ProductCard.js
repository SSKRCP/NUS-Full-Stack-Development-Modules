import React from "react";
import "../styles.css";

//***** Card Component */
function ProductCard(props) {
  return (
    <div
      style={{
        border: "1px solid #ddd",
        borderRadius: "8px",
        padding: "20px",
        marginBottom: "20px",
        maxWidth: "300px",
        fontSize: "13px",
      }}
    >
      <h3>{props.productName}</h3>
      <p>{props.productDesc}</p>
      {
        <div style={{ marginTop: "10px", color: "gray" }}>
          ${props.productPrice}
        </div>
      }
    </div>
  );
}
export default ProductCard;
