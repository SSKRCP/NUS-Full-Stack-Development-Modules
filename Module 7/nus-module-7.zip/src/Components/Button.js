import React from "react";
import "../styles.css";

//*** Button Component */
function Button(props) {
  const ButtonClicked = () => {
    switch (props.ButtonLabel) {
      case "Very Good":
        alert("You chose the excellent feedback. Thank you!");
        break;
      case "Good":
        alert("You chose a positive feedback. We appreciate it!");
        break;
      case "Average":
        alert(
          "We understand that the huge improvement is required! Please believe in us."
        );
        break;
      case "Poor":
        alert(
          "We are sorry for the inconvenience! We will come back again with a better version!"
        );
        break;
      default:
        alert("Please choose your feedback!");
        break;
    }
  };

  return (
    <div className="outerDiv">
      <button className="ButtonComponent" onClick={ButtonClicked}>
        {props.ButtonLabel}
      </button>
    </div>
  );
}

export default Button;
