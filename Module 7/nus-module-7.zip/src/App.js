import "./styles.css";
import Button from "./Components/Button";
import ProductCard from "./Components/ProductCard";

export default function App() {
  return (
    <div className="App">
      <h1>NUS Module 7</h1>
      <h2>Task 2 : Component Creation and Reusability </h2>
      <h3> Demo for reusable componets - Button and Card </h3>

      <hr />
      <h5>Below is our product list! Please take a look.</h5>
      <div
        style={{
          display: "flex",
          gap: "10px",
          justifyContent: "center",
          flexWrap: "wrap",
        }}
      >
        <ProductCard
          productName="Revlon Lipstick"
          productDesc="Revlon Super Lustrous Lipstick, Creamy Formula For Soft, Fuller-Looking Lips"
          productPrice="12.95"
        />
        <ProductCard
          productName="Revlon Skin-Caring Foundation"
          productDesc="Revlon Illuminance Skin-Caring Foundation is a liquid foundation that aims to improve skin appearance while providing a natural, radiant finish. "
          productPrice="33.25"
        />
        <ProductCard
          productName="Revlon Face Powder"
          productDesc="Revlon Face Powder by, ColorStay 16 Hour Face Makeup, Longwear Medium- Full Coverage with Flawless Finish, Shine & Oil Free. "
          productPrice="15.00"
        />
        <ProductCard
          productName="Lakme VitC+ facial serum"
          productDesc="Introducing the Lakme 9to5 VitC+ facial serum. Lakme’s first vitamin C serum in a revolutionary light weight formula that is enriched with the richest known source of Vitamin C."
          productPrice="26.74"
        />
        <ProductCard
          productName="Lakme Ultimate Glam Eye Liner"
          productDesc="Lakme Insta-Liner Water Resistant Eyeliner 9ml is crafted with care amidst the serene slopes of the Himalayas."
          productPrice="8.00"
        />
      </div>
      <hr />
      <h5>
        Please give your valuable feedback by clicking one of the below button!
      </h5>
      <div
        style={{
          display: "flex",
          gap: "10px",
          justifyContent: "center",
          flexWrap: "wrap",
        }}
      >
        <Button ButtonLabel="Very Good"></Button>
        <Button ButtonLabel="Good"></Button>
        <Button ButtonLabel="Average"></Button>
        <Button ButtonLabel="Poor"></Button>
      </div>
    </div>
  );
}
