
//*** Declare variable x and assign value 10 to it. */
var x  = 10;

//*** Declare variable y and assign value 'Hello' to it. */
var y = "Hello";

//*** Decalre variable 'result'. Concatenate the values of  y and x and store  it in variable 'result' */
var result = y + x;

//**** Print the value of variable 'result' to the console */
console.log(result);